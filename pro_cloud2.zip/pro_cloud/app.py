import os
from flask import Flask, render_template, abort

app = Flask(__name__)

# قاعدة بيانات وهمية للوصفات منظمة حسب الفئة
# الصور يتم تحميلها من مسار وهمي للتخزين السحابي
recipes_by_category = {
    "حلويات": [
        {
            "id": "1-1",
            "name": "كيكة الشوكولاتة",
            "image_url": "https://storage.googleapis.com/my-simulated-cloud-storage/chocolate_cake.jpg",
            "description": "كيكة لذيذة ورطبة غنية بطعم الشوكولاتة، مثالية لكل المناسبات.",
            "ingredients": ["كوب دقيق", "نصف كوب سكر", "نصف كوب كاكاو", "بيضة", "نصف كوب حليب"],
            "instructions": ["اخلط المكونات الجافة معًا.", "أضف المكونات السائلة واخلط جيدًا.", "اسكب الخليط في قالب الخبز واخبزه لمدة 30 دقيقة."]
        },
        {
            "id": "1-2",
            "name": "كنافة بالقشطة",
            "image_url": "https://storage.googleapis.com/my-simulated-cloud-storage/kunafa.jpg",
            "description": "حلى شرقي شهير بطبقات من عجينة الكنافة المقرمشة والقشطة الغنية.",
            "ingredients": ["نصف كيلو عجينة كنافة", "كوب سمن مذاب", "كوب قشطة", "شيرة (قطر)"],
            "instructions": ["افرد عجينة الكنافة في صينية وأضف السمن.", "ضع القشطة في المنتصف.", "اخبزها حتى تصبح ذهبية اللون.", "اسقِ الكنافة بالشيرة وقدمها ساخنة."]
        }
    ],
    "مأكولات بحرية": [
        {
            "id": "2-1",
            "name": "سمك فيليه مشوي",
            "image_url": "https://storage.googleapis.com/my-simulated-cloud-storage/grilled_fish.jpg",
            "description": "سمك فيليه مشوي بتتبيلة الليمون والأعشاب، طبق صحي ولذيذ.",
            "ingredients": ["كيلو سمك فيليه", "عصير ليمونة", "ملعقتان زيت زيتون", "فص ثوم مهروس", "ملح وفلفل"],
            "instructions": ["تبل السمك بالليمون والثوم والملح والفلفل.", "اتركه في التتبيلة لمدة 30 دقيقة.", "اشويه على الشواية أو في الفرن حتى ينضج."]
        },
        {
            "id": "2-2",
            "name": "جمبري مقلي",
            "image_url": "https://storage.googleapis.com/my-simulated-cloud-storage/fried_shrimp.jpg",
            "description": "جمبري مقرمش ولذيذ، طبق جانبي رائع أو وجبة خفيفة.",
            "ingredients": ["نصف كيلو جمبري مقشر", "كوب دقيق", "بيضة", "توابل (كمون، بابريكا)", "زيت للقلي"],
            "instructions": ["اخلط الدقيق مع التوابل.", "اغمس الجمبري في البيض ثم في خليط الدقيق.", "اقليه في زيت ساخن حتى يصبح ذهبي اللون."]
        }
    ],
    "أطباق رئيسية": [
        {
            "id": "3-1",
            "name": "البيتزا الإيطالية",
            "image_url": "https://storage.googleapis.com/my-simulated-cloud-storage/italian_pizza.jpg",
            "description": "بيتزا تقليدية بعجينة رقيقة ومقرمشة وصلصة طماطم غنية.",
            "ingredients": ["كوبان من الدقيق", "ملعقة خميرة", "ماء دافئ", "صلصة طماطم", "جبنة موتزاريلا"],
            "instructions": ["اعجن الدقيق مع الخميرة والماء حتى تتشكل عجينة.", "اترك العجينة تتخمر لمدة ساعة.", "افرد العجينة، أضف الصلصة والمكونات الأخرى واخبزها."]
        },
        {
            "id": "3-2",
            "name": "دجاج مشوي بالفرن",
            "image_url": "https://storage.googleapis.com/my-simulated-cloud-storage/roasted_chicken.jpg",
            "description": "دجاج كامل مشوي بتتبيلة خاصة، طري من الداخل ومقرمش من الخارج.",
            "ingredients": ["دجاجة كاملة", "ملعقتان زيت زيتون", "ملح وفلفل", "بابريكا", "أعشاب مجففة (زعتر، روزماري)"],
            "instructions": ["تبل الدجاجة جيدًا من الداخل والخارج بالملح والتوابل.", "ضعها في صينية فرن وأضف الزيت.", "اخبزها في فرن مسخن مسبقًا على درجة حرارة 180 مئوية لمدة ساعة ونصف."]
        }
    ]
}

@app.route('/')
def home():
    return render_template('home.html', categories=recipes_by_category)

@app.route('/category/<category_name>')
def category_page(category_name):
    category_name = category_name.replace('_', ' ')
    if category_name in recipes_by_category:
        recipes = recipes_by_category[category_name]
        return render_template('category.html', category_name=category_name, recipes=recipes)
    abort(404)

@app.route('/recipe/<string:recipe_id>')
def recipe_details(recipe_id):
    recipe = None
    for category in recipes_by_category.values():
        for r in category:
            if r['id'] == recipe_id:
                recipe = r
                break
        if recipe:
            break
    if recipe:
        return render_template('recipe.html', recipe=recipe)
    abort(404)

if __name__ == '__main__':
    app.run(debug=True)